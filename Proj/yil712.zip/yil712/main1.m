[FeatureA, FeatureB, FeatureC, FeatureD] = getNormalizedCMFeature()
[confusion11] = Proj_classifier1(FeatureA, FeatureB)
[confusion12] = Proj_classifier1(FeatureA, FeatureC)
[confusion13] = Proj_classifier1(FeatureA, FeatureD)
[confusion21] = Proj_classifier2(FeatureA, FeatureB)
[confusion22] = Proj_classifier2(FeatureA, FeatureC)
[confusion23] = Proj_classifier2(FeatureA, FeatureD)
[confusion31] = Proj_classifier3(FeatureA, FeatureB)
[confusion32] = Proj_classifier3(FeatureA, FeatureC)
[confusion33] = Proj_classifier3(FeatureA, FeatureD)
[confusion41] = Proj_classifier4(FeatureA, FeatureA)
[confusion42] = Proj_classifier4(FeatureA, FeatureB)
[confusion43] = Proj_classifier4(FeatureA, FeatureD)







